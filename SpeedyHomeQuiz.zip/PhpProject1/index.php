<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="CSS/newCascadeStyleSheet.css" rel="stylesheet" type="text/css"/>
        <title></title>
    </head>
    <body>
        <div class="container border">
            <table class="table" cellspacing="0">
                <tr>
                    <td class="left-column">
                        <img src="picture/adwords.png" alt="" width="50%"/>
                    </td>
                    <td class="middle table-shadow"></td>
                    <td style="width: 2%" class="table-shadow"></td>
                    <td class="table-shadow"></td>
                    <td class="right-column table-shadow">
                        <img src="picture/email.png" alt="" class="icon"/>
                        <img src="picture/bell.png" alt="" class="icon"/>
                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_01.jpg" alt="" style="border-radius: 50%; width: 13%; margin-bottom: 5px">
                        <a style="margin-bottom: 10px">
                            Vincent Porter
                        </a>
                    </td>
                </tr>                
                <tr>
                    <td class="left-row"></td>
                    <td  colspan="2" rowspan="7" style="width:10%">
                        <div class="chatlist">
                            <aside>
                                <div class="chatlist_header">Search Messages</div>
                                <header>
                                    <input type="text" placeholder="Type & Hit Enter" class="input_search">
                                </header>
                                <div class="chatlist_header">Recent Talks</div>
                                <div style="height: 200px">
                                   <ul>
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_01.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status orange"></span>
                                                offline
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_02.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status green"></span>
                                                online
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_03.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status orange"></span>
                                                offline
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_04.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status green"></span>
                                                online
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_05.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status orange"></span>
                                                offline
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_06.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status green"></span>
                                                online
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_07.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status green"></span>
                                                online
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_08.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status green"></span>
                                                online
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_09.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status green"></span>
                                                online
                                            </h3>
                                        </div>
                                    </li>
                                    <hr class="line">
                                    <li>
                                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_10.jpg" alt="">
                                        <div>
                                            <h2>Prénom Nom</h2>
                                            <h3>
                                                <span class="status orange"></span>
                                                offline
                                            </h3>
                                        </div>
                                    </li>
                                </ul> 
                                </div>
                                
                            </aside>
                        </div>
                    </td>
                    <td colspan="2" rowspan="7" class="chat">
                        <main>
                            <header>
                                <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/1940306/chat_avatar_01.jpg" alt="">
                                <div>
                                    <h2>Vincent Porter</h2>
                                </div>
                            </header>
                            <div>
                                <ul id="chat">
                                    <li class="you">                                    
                                        <div class="message">
                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                                        </div>
                                        <div class="entete">
                                            <span class="status green"></span>
                                            <h3>10 min ago</h3>
                                        </div>
                                    </li>
                                    <li class="me">

                                        <div class="message">
                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                                        </div>
                                        <div class="entete">
                                            <h3>9 min ago</h3>
                                            <span class="status blue"></span>
                                        </div>
                                    </li>
                                    <li class="me">

                                        <div class="message">
                                            OK
                                        </div>
                                        <div class="entete">
                                            <h3>9 min ago</h3>
                                            <span class="status blue"></span>
                                        </div>
                                    </li>
                                    <li class="you">

                                        <div class="message">
                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                                        </div>
                                        <div class="entete">
                                            <span class="status green"></span>
                                            <h3>9 min ago</h3>
                                        </div>
                                    </li>
                                    <li class="me">

                                        <div class="message">
                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                                        </div>
                                        <div class="entete">
                                            <h3>8 min ago</h3>
                                            <span class="status blue"></span>
                                        </div>
                                    </li>
                                    <li class="me">

                                        <div class="message">
                                            OK
                                        </div>
                                        <div class="entete">
                                            <h3>answered by bot</h3>
                                            <h3>7 min ago</h3>
                                            <span class="status blue"></span>
                                        </div>
                                    </li>
                                    <li class="you">

                                        <div class="message">
                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                                        </div>
                                        <div class="entete">
                                            <span class="status green"></span>
                                            <h3>7 min ago</h3>
                                        </div>
                                    </li>
                                    <li class="you">

                                        <div class="message">
                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                                        </div>
                                        <div class="entete">
                                            <span class="status green"></span>
                                            <h3>7 min ago</h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <footer>
                                <table style="width: 100%" cellspacing="0">
                                    <tr>
                                        <td style="width: 10%">
                                            <img src="picture/paper-clip.png" alt="" style="margin: 5px"/>
                                            <img src="picture/happy.png" alt="" style="margin: 5px"/>
                                        </td>
                                        <td>
                                            <input placeholder="Type a message" class="msg"></input>
                                        </td>
                                        <td style="width: 5%; padding-left: 20px">
                                            <img src="picture/paper-plane.png" alt=""/>
                                        </td>
                                    </tr>
                                </table>      
                            </footer>
                        </main>
                    </td>
                </tr>
                <tr>
                    <td class="left-row">
                        <img src="picture/menu.png" alt="" style="width: 40%"/>
                    </td>
                </tr>
                <tr>
                    <td class="left-row" style="background: #ffe6e9">
                        <img src="picture/message.png" alt="" style="width: 40%"/>
                    </td>
                </tr>
                <tr>
                    <td class="left-row">
                        <img src="picture/molecular.png" alt="" style="width: 40%"/>
                    </td>
                </tr>
                <tr>
                    <td class="left-row">
                        <img src="picture/television.png" alt="" style="width: 40%"/>
                    </td>
                </tr>
                <tr>
                    <td class="left-row">
                        <img src="picture/antenna.png" alt="" style="width: 40%"/>
                    </td>
                </tr>
                <tr>
                    <td class="left-row">
                        <img src="picture/menu (1).png" alt="" style="width: 40%"/>
                    </td>
                </tr>
            </table>
        </div>
    </body>
</html>
