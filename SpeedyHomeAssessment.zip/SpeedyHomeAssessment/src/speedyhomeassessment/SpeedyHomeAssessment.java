/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package speedyhomeassessment;

import java.util.Scanner;

/**
 *
 * @author hazmi
 */
public class SpeedyHomeAssessment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        double anywhereZone1 = 2.50;
        double anyoneOutsideZone1 = 2.00;
        double anyTwoZonesInclZone1 = 3.00;
        double anyTwoZonesExclZone1 = 2.25;
        double anyThreeZone = 3.20;
        double anyBusJourney = 1.80;
        
        double balance = 30.00;

        Scanner obj = new Scanner(System.in);
        System.out.println("Process starting with card balance of £" + balance);
        

        balance = balance - anywhereZone1; // 1st Trip

        System.out.println("Balance after tube trip from Holborn to Earl's Court is = £" + balance);

        balance = balance - anyBusJourney; // 2nd Trip
        

        System.out.println("Balance after bus trip from Earl's Court to Chelsea is = £" + balance);

        balance = balance - anyoneOutsideZone1; // 3rd Trip

        System.out.println("Balance after tube trip from Earl's Court to Hammersmith is = £" + balance);

    }

}
